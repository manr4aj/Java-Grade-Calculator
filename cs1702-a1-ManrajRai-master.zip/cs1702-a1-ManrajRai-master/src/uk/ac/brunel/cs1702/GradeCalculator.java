package uk.ac.brunel.cs1702;

public class GradeCalculator {

	// declared variables static to keep constant and final so that it can not change
	static final double W1 = 0.10, W2 = 0.10,W3 = 0.15,W4 = 0.15,W5 = 0.25,W6 = 0.25;
	static double a1, a2, a3, a4, a5, a6;
	static String v1, v2;

	public static void main(String[] args) {
			
	double TotalMarks;
	char FinalGrade = 'A';
	String VivaGrade;
	TotalMarks = (a1 * W1) + (a2 * W2) + (a3 * W3) + (a4 * W4) + (a5 * W5) + (a6 * W6);
	// total marks is the worksheets and the weight of the worksheets calculated together
	// use of the if else statements
	if (v2.compareTo(v1) >= 0) {
		VivaGrade = v1;
	} else{ VivaGrade = v2;
	}
		// compares the v2 with v1
	if (VivaGrade == "A" && TotalMarks >= 70 && (a5 * W5)+ (a6 * W6) >= 40){
		FinalGrade = 'A';
	}
	// || this represents or so that 
	else if ((VivaGrade == "A"|| VivaGrade == "B")&& TotalMarks >= 60 && (a5 * W5)+ (a6 * W6) >= 40){
		FinalGrade = 'B';
	}
	else if ((VivaGrade == "A"|| VivaGrade == "B"|| VivaGrade == "C") &&TotalMarks >= 50){
		FinalGrade = 'C'; 
	}
		
	else if ((VivaGrade == "A"|| VivaGrade == "B"|| VivaGrade == "C"|| VivaGrade == "D")&&TotalMarks >= 40) {
		FinalGrade = 'D';
	}

	else if (VivaGrade=="F"){
		FinalGrade='F';
	}
	
		 System.out.println("Total marks: "+ TotalMarks);
		 System.out.println("Viva grade: " +  VivaGrade);
		 System.out.println("Final grade: " + FinalGrade);
		 // displays the output of the grade calculator
		
	}
}